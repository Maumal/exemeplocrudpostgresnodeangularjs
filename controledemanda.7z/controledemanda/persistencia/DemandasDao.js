
function DemandasDao(connection) {
    this._connection = connection;
}


 DemandasDao.prototype.buscaquadrosporequipe = function(equipe,callback) {
  console.log("entrou no dao");
  console.log(equipe);

 this._connection.query('SELECT * FROM cenopsp1981controledemandas.tb_quadro where CD_EQUIPE = ?', [equipe.CD_EQUIPE], callback);
 this._connection.end(); 
 }

 DemandasDao.prototype.buscacartoesporquadro = function(quadro,callback) {

 //   this._connection.query('SELECT DISTINCT * FROM cenopsp1981controledemandas.tb_cartao as c INNER JOIN cenopsp1981controledemandas.tb_cartao_lista as l ON c.cd_cartao_lista=l.cd_cartao_lista where CD_QUADRO = ?', [quadro.CD_QUADRO], callback);
     this._connection.query('SELECT  * FROM cenopsp1981controledemandas.tb_cartao as c INNER JOIN cenopsp1981controledemandas.tb_cartao_lista as l ON c.cd_cartao_lista=l.cd_cartao_lista INNER JOIN cenopsp1981controledemandas.tb_quadro as q on c.CD_QUADRO=q.CD_QUADRO where c.CD_QUADRO= ?', [quadro.CD_QUADRO], callback);
     this._connection.end(); 
 }

module.exports = function(){
    return DemandasDao;   
};




