var path = require('path');


module.exports = function(app){

  app.get('/', function(req, res){
    console.log('index.html carregado')
    // res.sendFile(path.join(__dirname, '../', 'views', 'cadastroequipes.html'));
   res.sendFile(path.join(__dirname, '../', 'views', 'index.html'));
  });


app.get('/nav', function(req, res){
    
    // res.sendFile(path.join(__dirname, '../', 'views', 'cadastroequipes.html'));
   res.sendFile(path.join(__dirname, '../', 'views', 'header.html'));
  });


 app.get('/cadastroequipes', function(req, res){
    console.log('cadastroequipes carregado')
     res.sendFile(path.join(__dirname, '../', 'views', 'cadastroequipes.html'));
  });

  app.get('/cadastrofuncionarios', function(req, res){
    console.log('cadastroequipes carregado')
     res.sendFile(path.join(__dirname, '../', 'views', 'cadastrofuncionarios.html'));
  });

    app.get('/cadastroquadros', function(req, res){
    console.log('cadastroequipes carregado')
     res.sendFile(path.join(__dirname, '../', 'views', 'cadastroquadros.html'));
  });

 app.get('/cadastrocartoes', function(req, res){
    console.log('cadastroequipes carregado')
     res.sendFile(path.join(__dirname, '../', 'views', 'cadastrocartoes.html'));
  });

 app.get('/demandas', function(req, res){
    console.log('demandas gerais')
     res.sendFile(path.join(__dirname, '../', 'views', 'demandas.html'));
  });

app.get('/logo', function(req, res){
    
    // res.sendFile(path.join(__dirname, '../', 'views', 'cadastroequipes.html'));
   res.sendFile(path.join(__dirname, '../', 'public', '/img/logo.png'));
  });



app.get('/pdf', function(req, res){    
    // res.sendFile(path.join(__dirname, '../', 'views', 'cadastroequipes.html'));
   res.sendFile(path.join(__dirname, '../', 'public', '/img/a.pdf'));
});




}
