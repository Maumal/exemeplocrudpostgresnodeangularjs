//Criamos um módulo Angular chamado listaEquipe
var listaequipe = angular.module('listaequipe',[]);

  listaequipe.controller('equipeController', function($scope, $http) {
          


 $scope.buscarEquipes = function() {        
           $scope.equipes = [];
           var request = $http.get('/equipe');           
           request.success(function(data) {
           $scope.equipes = data; 
           console.log(data);           
        });
           request.error(function(data){
            console.log('Error: ' + data);
        });
 }



    //Chamando a função buscar
$scope.buscarEquipes();

  // Quando clicar no botão Criar, envia informações para a API Node
 $scope.criarEquipe = function() {
    //  console.log($scope.formEquipe);
        $http.post('/equipe', $scope.formEquipe)
            .success(function(data) {            
           // Limpa o formulário para criação de outras equipes
             $scope.formEquipe = {};            
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });
 $scope.buscarEquipes();  
    };



    // Ao clicar no botão Remover, deleta a aquipe
$scope.deletarEquipe = function(id) {
  console.log(id);
        $http.delete('/equipe/' + id)
            .success(function(data) {
              // $scope.formEquipe = {};  
              //  $scope.equipes = data;
                console.log(data);
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });
$scope.buscarEquipes(); 
    };

  

     // Ao clicar no botão Editar, edita a equipe
$scope.editarEquipe = function(id) {
        $http.get('/equipe/' + id)
            .success(function(data) {
             // console.log(data);
                $scope.teste3=data;


               $scope.formEquipe =  $scope.teste3[0];             
            

                             })
            .error(function(data) {
                console.log('Error: ' + data);
            });
    };

    $scope.limparEquipe = function() {  
                $scope.formEquipe = {};         
    };


    
$scope.atualizarEquipe = function() { 
        $http.put('/equipe/' + $scope.formEquipe.CD_EQUIPE, $scope.formEquipe)
            .success(function(data) {             
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });
            $scope.limparEquipe();
$scope.buscarEquipes(); 
    };






  })










      




  