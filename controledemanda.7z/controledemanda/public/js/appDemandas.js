
var appDemandas = angular.module('appDemandas',['angular.filter','720kb.datepicker']);







  appDemandas.controller('demandasController', function($scope, $http) {

 
$scope.buscarEquipes = function() {        
           $scope.equipes = [];
           var request = $http.get('/equipe');    
           request.success(function(data) {
           $scope.equipes = data; 
         //  console.log(data);           
        });
           request.error(function(data){
            console.log('Error: ' + data);
        });

 }
 $scope.quadros={}; 
 $scope.cartoes={};  


$scope.buscarQuadrosEquipes = function(id) {
        $http.get('/quadro/' + id)
            .success(function(data) {
                
                $scope.quadros=data;
             //  $scope.formFunci = $scope.funcionario[0]; 
         //    $scope.buscarCartoesQuadros();
        
                             })
            .error(function(data) {
                console.log('Error: ' + data);
            });
};


$scope.buscarCartoesQuadros = function(id) {

  // $scope.teste(id);
        $http.get('/cartoes/cartoes/' + id)
            .success(function(data) {


              $scope.cartoes=data;           
                                         
       //  $scope.btnInserir();
              })


            .error(function(data) {
                console.log('Error: ' + data);
            });
};






$scope.buscarCartoesLista = function() {        
           $scope.cartoesLista = [];
           var request = $http.get('/cartoeslista');    
           request.success(function(data) {
           $scope.cartoesLista = data; 

        //   console.log(data);           
        });
           request.error(function(data){
            console.log('Error: ' + data);
        });

 }



 $scope.buscarCartoesListaPriorizacao = function() {        
           
           var request = $http.get('/cartoeslistapriorizacao');    
           request.success(function(data) {
           $scope.cartaoNivelPriorizacao = data; 
        //   console.log(data);           
        });
           request.error(function(data){
            console.log('Error: ' + data);
        });

 }



 $scope.criarCartao = function() {    
        $http.post('/cartoes', $scope.formCartao)
            .success(function(data) {            
           // Limpa o formulário para criação de outras equipes
             $scope.formCartao = {};            
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });


};






$scope.buscarQuadros = function() {        
           $scope.quadross = [];
           var request = $http.get('/quadros');    
           request.success(function(data) {
           $scope.quadross = data; 
           console.log(data);           
        });
           request.error(function(data){
            console.log('Error: ' + data);
        });


         

 }







$scope.atualizarCartao = function() {
     $http.put('/cartoes/' + $scope.formTarefa.CD_CARTAO, $scope.formTarefa)
            .success(function(data) {
            //  $scope.limparQuadro();
               $scope.formCartao = {};  
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });


};



$scope.carregarTarefa = function(carta) {
$scope.carta2=angular.copy(carta);
};



$scope.atualizarTarefa = function() {
     $http.put('/cartoes/'+$scope.carta2.CD_CARTAO, $scope.carta2)
            .success(function(data) {
            //  $scope.limparQuadro();
        //       $scope.formCartao = {}; 
   



            })
            .error(function(data) {
                console.log('Error: ' + data);
            });


$scope.buscarCartoesQuadros($scope.carta2.CD_QUADRO);

};









$scope.buscarEquipes();
$scope.buscarCartoesLista();
$scope.buscarCartoesListaPriorizacao();
$scope.buscarQuadros();




$scope.limparCartao=function(){
  $scope.formCartao={};
}













})








//https://cdnjs.com/libraries/angular-filter

//https://github.com/a8m/angular-filter