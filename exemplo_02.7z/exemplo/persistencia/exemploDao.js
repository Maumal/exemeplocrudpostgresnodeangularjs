const Pool = require('pg').Pool
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: 'postgres',
  port: 5432,
})

const getClientes = (request, response) => {
  pool.query('select * from clientes.tb_clientes  order by id desc limit 10;', (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
};

const getClientesById  = (request, response) => {
  const id = parseInt(request.params.id)
  console.log(id);

  pool.query('select * from clientes.tb_clientes WHERE id = $1', [id], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const createCliente = (request, response) => {
  const { codigo, nome,endereco,email } = request.body
console.log(request.body);


  pool.query('INSERT INTO clientes.tb_clientes (cd_cliente, nm_cliente, ds_endereco, ds_email) VALUES ($1, $2,$3,$4)', [codigo,nome,endereco, email], (error, results) => {
    if (error) {
console.log('fodeo'+error);
response.status(304).send(error)
    }else{
      response.status(201).send(`Cliente adicionado`)
    }
    
  })
}

const updateCliente = (request, response) => {
const { id,codigo, nome,endereco,email } = request.body

console.log(request.body);

  pool.query(
    'UPDATE clientes.tb_clientes SET cd_cliente = $1, nm_cliente = $2,ds_endereco=$3,ds_email=$4 WHERE id = $5',
    [codigo, nome, endereco,email,id],
    (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).send(`Usuário modificado com id ID: ${id}`)
    }
  )
}

const deleteCliente = (request, response) => {
const id = parseInt(request.params.id)

  pool.query('DELETE FROM clientes.tb_clientes WHERE cd_cliente = $1', [id], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).send(`Usuário deletado ID: ${id}`)
  })
}

module.exports = {
  getClientes  
  ,getClientesById 
  ,createCliente
  ,updateCliente
  ,deleteCliente
}

