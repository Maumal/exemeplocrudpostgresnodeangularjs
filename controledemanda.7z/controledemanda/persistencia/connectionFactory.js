var mysql  = require('mysql');



function createDBConnection(){
		return mysql.createConnection({
			host: '172.29.14.112',
			user: 'userRW',
			password: 'WRresu',
			database: 'cenopsp1981arh'
		});
}
module.exports = function() {
	return createDBConnection;
}
/*
var mysql  = require('mysql');
function createDBConnection(){
		return mysql.createConnection({
			host: '172.29.14.112',
			user: 'userRW',
			password: 'WRresu',
			database: 'cenopsp1981arh'
		});
}


module.exports = function() {
	return createDBConnection;
}

/*
var mysql  = require('mysql');
function createDBConnection(){
		return mysql.createConnection({
			host: 'localhost',
			user: 'root',
			password: '',
			database: 'payfast'
		});
}
module.exports = function() {
	return createDBConnection;
}*/
