var app = angular.module('app', []);

app.controller('myController', function ($scope, $http) {

  // $scope.buscarclientes = function() {   
  //   $scope.clientes =null;       
  //   var request = $http.get('/clientes');    
  //   request.success(function(data) {
  //   $scope.clientes =data;             
  // });
  //   request.error(function(data){
  //    console.log('Error: ' + data);
  // });
  // };

  $scope.buscarclientes = function () {
    $scope.clientes = null;
    $http({
      method: 'GET',
      url: '/clientes'
    }).then(function successCallback(response) {
      $scope.clientes = response;
    }, function errorCallback(response) {
      console.log('Error: ' + response);
    });
  };


  $scope.buscarclientes();


  $scope.criarCliente = function () {
    var cliente = $scope.formCliente;
    $http({
      url: '/clientes',
      method: "POST",
      data: cliente
    })
      .then(function (response) {

      },
        function (response) { // optional
          // failed
        });

    $scope.buscarclientes();
    $scope.limparCliente();
  };

  $scope.limparCliente = function () {
    $scope.formCliente = null;
  };


});



$scope.deletarCliente = function (id) {

  $scope.aa = 'dsadasdasd' + id;
  $http({
    method: 'DELETE',
    url: '/clientes',
    data: id
  }).then(function successCallback(response) {
  }, function errorCallback(response) {
  });
  $scope.buscarEquipes();
};



$scope.deletar = function () {
  $scope.formCliente = null;
};

