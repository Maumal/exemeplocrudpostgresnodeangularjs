var path = require('path');


module.exports = function(app){

app.get('/cartoes', function(req, res){
    var connection = app.persistencia.connectionFactory();  
    var CartaoDao = new app.persistencia.CartaoDao(connection);
    CartaoDao.listaCartoes(function(erro, resultado){
      if(erro){
    //    console.log('Erro ao inserir no banco:' + erro);
        res.status(500).send(erro);
        return;
      } else {
  //    console.log('busca cartoes');
      res.status(201).json(resultado);
return;
}
});
});



app.get('/cartoeslista', function(req, res){
    var connection = app.persistencia.connectionFactory();  
    var CartaoDao = new app.persistencia.CartaoDao(connection);
    CartaoDao.listaCartaoLista(function(erro, resultado){
      if(erro){
   //     console.log('Erro ao inserir no banco:' + erro);
        res.status(500).send(erro);
        return;
      } else {
  //    console.log('busca listaCartoes cartoes');
      res.status(201).json(resultado);
return;
    }
    });
});

app.get('/cartoeslistapriorizacao', function(req, res){
    var connection = app.persistencia.connectionFactory();  
    var CartaoDao = new app.persistencia.CartaoDao(connection);
    CartaoDao.listaCartaoListaPriorizacao(function(erro, resultado){
      if(erro){
  //      console.log('Erro ao inserir no banco:' + erro);
        res.status(500).send(erro);
        return;
      } else {
     console.log('busca priorizacao');
      res.status(201).json(resultado);
return;
    }
    });
      });


app.post('/cartoes', function(req, res){
//console.log('Entrou xxxxx');
 var cartao = req.body;
// console.log(cartao);
    req.assert("NM_CARTAO",
      "nome do cartao é obrigatório")
    .notEmpty();

     req.assert("DS_CARTAO",
      "descriçao do cartao é obrigatório")
    .notEmpty();


  var erros = req.validationErrors();
    if (erros){
    //  console.log('Erros de validacao encontrados');
      res.status(400).send(erros);
      return;
    }
    

    
   // cartao.DT_FIM = req.params.DT_FIM;
    cartao.DT_INICIO = new Date;

//console.log('Entrou yyyyyy');   
//console.log(cartao);


   
    //console.log('processando uma requisicao de um novo cartao');
    
    var connection = app.persistencia.connectionFactory();
    var CartaoDao = new app.persistencia.CartaoDao(connection);
  
//console.log(cartao);
    CartaoDao.salvaCartao(cartao, function(erro, resultado){
      if(erro){
        console.log('Erro ao inserir no banco:' + erro);
        res.status(500).send(erro);
      } else {
     // console.log('cartão criado');
    //  console.log(cartao);
       //    res.location('/equipe/' +resultado);

      res.status(201).json(cartao);
    }
    });



  });

//rota editar
app.get('/cartoes/:CD_CARTAO', function(req, res){
    var cartao = {};
    var CD_CARTAO = req.params.CD_CARTAO;

    cartao.CD_CARTAO = CD_CARTAO;
   //  console.log("CD_CARTAO:"+CD_CARTAO);
  //  console.log("Quadro:"+cartao);
  //  equipe.DT_EXPIRACAO = new Date;

    var connection = app.persistencia.connectionFactory();
    var CartaoDao = new app.persistencia.CartaoDao(connection);
    CartaoDao.buscacartao(cartao, function(erro,resultado){
        if (erro){
          res.status(500).send(erro);
          return;
        }
        
        //console.log('equipe encontrada');
     //   console.log(resultado);
       res.status(201).json(resultado);
       return;
        
    });


  });


app.put('/cartoes/:CD_CARTAO', function(req, res){
var cartao = req.body;
console.log("entrou no put");
console.log(cartao);
var connection = app.persistencia.connectionFactory();
    var CartaoDao = new app.persistencia.CartaoDao(connection);

    CartaoDao.atualiza(cartao, function(erro){
        if (erro){
          res.status(500).send(erro);
          return;
        }

      //  console.log('cartao alterado');     
        
    });



  });



}