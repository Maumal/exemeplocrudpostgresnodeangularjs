//Criamos um módulo Angular chamado listaEquipe

var listafuncionarios = angular.module('listafuncionarios',[]);

  listafuncionarios.controller('funcionariosController', function($scope, $http) {
        

        $scope.buscarEquipes = function() {        
           $scope.equipes = [];
           var request = $http.get('/equipe');    
           request.success(function(data) {
           $scope.equipes = data; 
           console.log(data);           
        });
           request.error(function(data){
            console.log('Error: ' + data);
        });

 }//Chamando a função buscar
  $scope.buscarEquipes();


$scope.buscarFuncionariosEquipes = function() {        
           $scope.funcionarios = [];
           var request = $http.get('/funcionariosequipes');    
           request.success(function(data) {
           $scope.funcionarios = data; 
           console.log(data);           
        });
           request.error(function(data){
            console.log('Error: ' + data);
        });

 }//Chamando a função buscarFuncionariosEquipes
  $scope.buscarFuncionariosEquipes();



 $scope.criarFuncionario = function() {
      console.log($scope.formFunci);
        $http.post('/funcionario', $scope.formFunci)
            .success(function(data) {            
           // Limpa o formulário para criação de outras equipes
             $scope.formFunci = {};            
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });
 $scope.buscarEquipes();  
 $scope.buscarFuncionariosEquipes();
    };


$scope.deletarFuncionario = function(id) {
  console.log(id);
        $http.delete('/funcionario/' + id)
            .success(function(data) {
              // $scope.formEquipe = {};  
              //  $scope.equipes = data;
                console.log(data);
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });
$scope.buscarEquipes();  
 $scope.buscarFuncionariosEquipes();
    };

     // Ao clicar no botão Editar, edita a equipe


$scope.editarFuncionario = function(id) {
        $http.get('/funcionario/' + id)
            .success(function(data) {
              console.log(data);
                $scope.funcionario=data;
                $scope.formFunci = $scope.funcionario[0]; 
                             })
            .error(function(data) {
                console.log('Error: ' + data);
            });
    };

        // Ao clicar no botão Remover, deleta a aquipe
$scope.atualizarFuncionario = function() { 
     $http.put('/funcionario/' + $scope.formFunci.CD_EQUIPE_FUNCI, $scope.formFunci)
            .success(function(data) {
             
              
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });
$scope.buscarEquipes();  
 $scope.buscarFuncionariosEquipes();
    };




   $scope.limparFuncionario = function() {  
                $scope.formFunci = {};         
    };






  })










      




  