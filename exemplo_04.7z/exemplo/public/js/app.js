var app = angular.module('app', []);

app.controller('myController', function ($scope, $http) {

  // $scope.buscarclientes = function() {   
  //   $scope.clientes =null;       
  //   var request = $http.get('/clientes');    
  //   request.success(function(data) {
  //   $scope.clientes =data;             
  // });
  //   request.error(function(data){
  //    console.log('Error: ' + data);
  // });
  // };

  $scope.buscarclientes = function () {
    $scope.clientes = null;
    $http({
      method: 'GET',
      url: '/clientes'
    }).then(function successCallback(response) {
      $scope.clientes = response.data;
    }, function errorCallback(response) {
      console.log('Error: ' + response);
    });
  };


  $scope.buscarclientes();

  
  $scope.criarCliente = function () {
    var cliente = $scope.formCliente;
    $http({
      url: '/clientes',
      method: "POST",
      data: cliente
    })
      .then(function (response) {
      },
        function (response) { // optional
          // failed
    });

    $scope.buscarclientes();
    $scope.limparCliente();
  };

  $scope.limparCliente = function () {
    $scope.formCliente = null;
  };

  $scope.editarCliente = function (id) {  
    $scope.formCliente=[];   
    $scope.formCliente.nome=id;
    $scope.formCliente.endereco="id.ds_endereco";
    $scope.formCliente.email="id.ds_email";
  };


  $scope.deletarCliente = function (id) {
   $scope.aa = id;
    $http({      
      method: 'DELETE' ,
      url: '/clientes/'+id  
    }).then(function successCallback(response) {
     
     
    }, function errorCallback(response) {
    });
    $scope.buscarclientes();
    $scope.limparCliente();
  };
  
  


  














});




