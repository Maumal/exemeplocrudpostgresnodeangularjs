
function EquipeDao(connection) {
    this._connection = connection;
}



EquipeDao.prototype.listaequipe = function(callback) {
 this._connection.query('SELECT * FROM cenopsp1981controledemandas.tb_equipe where DT_EXPIRACAO>now()',callback);
	this._connection.end(); 
}

EquipeDao.prototype.salvaequipe = function(equipe,callback) {
	//console.log("entrou no dao");
	//console.log(equipe);
    this._connection.query('INSERT INTO cenopsp1981controledemandas.tb_equipe SET ?', equipe, callback);
this._connection.end(); 
}


EquipeDao.prototype.exclui = function(equipe,callback) {
    this._connection.query('UPDATE cenopsp1981controledemandas.tb_equipe SET DT_EXPIRACAO = ? where CD_EQUIPE = ?', [equipe.DT_EXPIRACAO, equipe.CD_EQUIPE], callback);
this._connection.end(); 
}

EquipeDao.prototype.buscaequipe = function(equipe,callback) {
	console.log("entrou no dao");
	console.log(equipe);

    this._connection.query('SELECT * FROM cenopsp1981controledemandas.tb_equipe where CD_EQUIPE = ?', [equipe.CD_EQUIPE], callback);
this._connection.end(); 
}

EquipeDao.prototype.atualiza = function(equipe,callback) {
    this._connection.query('UPDATE cenopsp1981controledemandas.tb_equipe SET NM_EQUIPE = ? , DS_EQUIPE=? where CD_EQUIPE = ?', [equipe.NM_EQUIPE,equipe.DS_EQUIPE, equipe.CD_EQUIPE], callback);

this._connection.end(); 
}

module.exports = function(){
    return EquipeDao;   
};




