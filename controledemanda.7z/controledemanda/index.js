var app = require('./config/custom-express')();

app.listen(2646, function(){
  console.log('Servidor rodando na porta 2646.');
});
