
var listaCartao = angular.module('listaCartao',['720kb.datepicker']);
  listaCartao.controller('cartaoController', function($scope, $http) {
$scope.buscarQuadros = function() {        
           $scope.quadros = [];
           var request = $http.get('/quadros');    
           request.success(function(data) {
           $scope.quadros = data; 
           console.log(data);           
        });
           request.error(function(data){
            console.log('Error: ' + data);
        });


         

 }
/*
  $scope.dataFim = function() {
    
         $scope.formCartao.DT_FIM=new Date()
  };
 
$scope.dataFim();*/

$scope.buscarCartoes = function() {        
           $scope.cartoes = [];
           var request = $http.get('/cartoes');    
           request.success(function(data) {
           $scope.cartoes = data; 
           console.log(data);           
        });
           request.error(function(data){
            console.log('Error: ' + data);
        });

 }//Chamando a função buscarFuncionariosEquipes
  


$scope.buscarCartoesLista = function() {        
           $scope.cartoesLista = [];
           var request = $http.get('/cartoeslista');    
           request.success(function(data) {
           $scope.cartoesLista = data; 
           console.log(data);           
        });
           request.error(function(data){
            console.log('Error: ' + data);
        });

 }//Chamando a função buscarFuncionariosEquipes



$scope.buscarCartoesListaPriorizacao = function() {        
           $scope.cartaoNivelPriorizacao = [];
           var request = $http.get('/cartoeslistapriorizacao');    
           request.success(function(data) {
           $scope.cartaoNivelPriorizacao = data; 
           console.log(data);           
        });
           request.error(function(data){
            console.log('Error: ' + data);
 });

}

 $scope.criarCartao = function() {    
        $http.post('/cartoes', $scope.formCartao)
            .success(function(data) {            
           // Limpa o formulário para criação de outras equipes
             $scope.formCartao = {};            
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });
             $scope.buscarQuadros();
 $scope.buscarCartoesListaPriorizacao();
 $scope.buscarCartoesLista();
 $scope.buscarCartoes();

};



$scope.editarCartao = function(id) {
        $http.get('/cartoes/' + id)
            .success(function(data) {
              console.log(data);
              $scope.cartao=data;
              $scope.formCartao = $scope.cartao[0];
              $scope.formCartao.NM_CARTAO=$scope.quadro[0].NM_CARTAO;
              $scope.formCartao.DS_CARTAO=$scope.quadro[0].DS_CARTAO;

              $scope.DT_FIM=$scope.quadro[0].DT_FIM; 

            //  $scope.DT_FIM=$filter('limitTo')($scope.DT_FIM, 10, 0);  


              $scope.formCartao.DT_FIM= $scope.DT_FIM;


                             })
            .error(function(data) {
                console.log('Error: ' + data);
            });
};


$scope.atualizarCartao = function() {
     $http.put('/cartoes/' + $scope.formCartao.CD_CARTAO, $scope.formCartao)
            .success(function(data) {
            //  $scope.limparQuadro();
               $scope.formCartao = {};  
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });

 $scope.buscarQuadros();
 $scope.buscarCartoesListaPriorizacao();
 $scope.buscarCartoesLista();
 $scope.buscarCartoes();
 $scope.limparCartao();
    };




$scope.limparCartao=function(){
  $scope.formCartao={};
}

 $scope.buscarQuadros();
 $scope.buscarCartoesListaPriorizacao();
 $scope.buscarCartoesLista();
 $scope.buscarCartoes();


})

