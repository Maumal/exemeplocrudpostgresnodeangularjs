
DROP TABLE  clientes.tb_clientes;

CREATE TABLE clientes.tb_clientes
(
  id SERIAL PRIMARY KEY,
  nm_cliente varchar(255) default NULL,
  ds_endereco varchar(255) default NULL,
  ds_email varchar(255) default NULL
);

INSERT INTO clientes.tb_clientes
  (cd_cliente,nm_cliente,ds_endereco,ds_email)
VALUES
  ('Cassady', '921-8897 Consequat Road', 'ornare.placerat.orci@est.edu'),
  ('Jin', 'P.O. Box 867, 9583 Iaculis Av.', 'neque.et@accumsansedfacilisis.org'),
  ('Barclay', '422-6187 Egestas. St.', 'natoque.penatibus.et@facilisis.ca'),
  ('Madeson', '6362 Aliquet, Av.', 'mi@molestie.org'),
  ('Ivana', '6504 Vel Rd.', 'facilisis.non@egetmollislectus.ca'),
  ('Linus', '2092 Mi Avenue', 'Nunc.mauris@eu.ca'),
  ('Jayme', '1421 Fusce Road', 'nisi.Aenean.eget@amet.edu'),
  ('Beau', '529-1802 Nec Av.', 'sem.Nulla.interdum@nonummyutmolestie.org'),
  ('Yoshio', '248-4798 Sem Road', 'Aenean.massa@amet.co.uk'),
  ('Wylie', 'Ap #956-1997 In Road', 'taciti.sociosqu@sodales.com');
INSERT INTO clientes.tb_clientes
  (cd_cliente,nm_cliente,ds_endereco,ds_email)
VALUES
  ('Chantale', '6753 Sociis Avenue', 'iaculis.aliquet.diam@ipsumdolorsit.net'),
  ('Dorian', '2796 Eu Avenue', 'vitae.risus@nonummyipsum.net'),
  ('Brenden', '988-3853 Justo Street', 'posuere.at@ante.com'),
  ('Daquan', 'Ap #482-3075 Nullam Av.', 'Aliquam.erat@Loremipsum.edu'),
  ('Chancellor', '4789 Augue, Av.', 'facilisis@ultricesposuere.co.uk'),
  ('Alisa', 'P.O. Box 106, 4366 Quis Road', 'aliquet@ante.edu'),
  ('Willa', '7209 Fusce St.', 'ac.libero@ante.ca'),
  ('Lani', '103-8259 Non St.', 'Donec.feugiat.metus@erateget.ca'),
  ('Brenden', 'P.O. Box 545, 9859 Lorem, Rd.', 'ac.ipsum.Phasellus@Crasinterdum.net'),
  ('Rose', '349-7429 Blandit St.', 'feugiat.tellus.lorem@justofaucibuslectus.net');
