
function FuncionarioDao(connection) {
    this._connection = connection;
}

FuncionarioDao.prototype.listaFuncionarioEquipe = function(callback) {
 this._connection.query('SELECT ef.CD_EQUIPE_FUNCI,ef.CD_FUNCI,e.NM_EQUIPE,f.NM_FUNCI FROM cenopsp1981controledemandas.tb_equipe_funci as ef INNER JOIN cenopsp1981arh.tb_vw_funci_equipe_all_manual as f ON ef.CD_FUNCI=f.CD_FUNCI INNER JOIN cenopsp1981controledemandas.tb_equipe as e ON ef.CD_EQUIPE=e.CD_EQUIPE where ef.DT_EXPIRACAO>now()',callback);
	this._connection.end(); 
}

FuncionarioDao.prototype.salvafuncionario = function(funcionario,callback) {
	//console.log("entrou no dao");
	//console.log(equipe);
    this._connection.query('INSERT INTO cenopsp1981controledemandas.tb_equipe_funci SET ?', funcionario, callback);
this._connection.end(); 
}


FuncionarioDao.prototype.exclui = function(funcionario,callback) {
    this._connection.query('UPDATE cenopsp1981controledemandas.tb_equipe_funci SET DT_EXPIRACAO = ? where CD_EQUIPE_FUNCI = ?', [funcionario.DT_EXPIRACAO, funcionario.CD_EQUIPE_FUNCI], callback);
this._connection.end(); 
}


FuncionarioDao.prototype.buscafuncionario = function(funcionario,callback) {
	console.log("entrou no dao");
	console.log(funcionario);

this._connection.query('SELECT * FROM cenopsp1981controledemandas.tb_equipe_funci where CD_EQUIPE_FUNCI = ?', [funcionario.CD_EQUIPE_FUNCI], callback);
this._connection.end(); 
}

FuncionarioDao.prototype.atualiza = function(funcionario,callback) {
    this._connection.query('UPDATE cenopsp1981controledemandas.tb_equipe_funci SET CD_EQUIPE = ? where CD_EQUIPE_FUNCI = ?', [funcionario.CD_EQUIPE, funcionario.CD_EQUIPE_FUNCI], callback);




this._connection.end(); 
}


module.exports = function(){
    return FuncionarioDao;   
};