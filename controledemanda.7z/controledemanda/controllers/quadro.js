var path = require('path');


module.exports = function(app){



  app.get('/quadros', function(req, res){

    console.log('entro no get simples');
    var connection = app.persistencia.connectionFactory();  
    var QuadroDao = new app.persistencia.QuadroDao(connection);
    QuadroDao.listaQuadros(function(erro, resultado){
      if(erro){
        console.log('Erro ao inserir no banco:' + erro);
        res.status(500).send(erro);
        return;
      } else {
    
    //  console.log(resultado);
      res.status(201).json(resultado);
return;
    }
    });
      });





app.post('/quadro', function(req, res){
  console.log('entro no post');

 
 
    req.assert("NM_Quadro",
      "códido da equipe eh obrigatorio")
    .notEmpty();

    var erros = req.validationErrors();
    if (erros){
      console.log('Erros de validacao encontrados');
      res.status(400).send(erros);
      return;
    }
    var quadro = req.body;
    
    quadro.DT_INICIO = new Date;



   
    console.log('processando uma requisicao de um novo pagamento');
    var connection = app.persistencia.connectionFactory();
    var QuadroDao = new app.persistencia.QuadroDao(connection);
    console.log("antes do dao");
console.log(quadro);
    QuadroDao.salvaQuadro(quadro, function(erro, resultado){
      if(erro){
        console.log('Erro ao inserir no banco:' + erro);
        res.status(500).send(erro);
      } else {
      console.log('funcionário criado');
      console.log(quadro);
       //    res.location('/equipe/' +resultado);

      res.status(201).json(quadro);
    }
    });

  });




//rota editar
app.get('/quadros/:CD_QUADRO', function(req, res){
   console.log('entro no get com id');
    var quadro = {};
    var CD_QUADRO = req.params.CD_QUADRO;
    quadro.CD_QUADRO = CD_QUADRO;
    console.log("CD_Quadro:"+CD_QUADRO);
    console.log("Quadro:"+quadro);
  //  equipe.DT_EXPIRACAO = new Date;
    var connection = app.persistencia.connectionFactory();
    var QuadroDao = new app.persistencia.QuadroDao(connection);
    QuadroDao.buscaquadro(quadro, function(erro,resultado){
        if (erro){
          res.status(500).send(erro);
          return;
        }        
        //console.log('equipe encontrada');
        console.log(resultado);
       res.status(201).json(resultado);
       return;        
    });
  });




app.put('/quadros/:CD_QUADRO', function(req, res){
console.log('entro no put');
var quadro = req.body;
console.log(quadro);


console.log("entrou no put2");
/*
var CD_QUADRO = req.params.CD_QUADRO;
quadro.CD_QUADRO=CD_QUADRO;
var NM_QUADRO = req.params.NM_Quadro;
quadro.NM_QUADRO=NM_QUADRO;*/

//quadro.CD_QUADRO=req.params.CD_QUADRO;
//quadro.NM_QUADRO=quadro.NM_Quadro;
console.log(quadro);


var connection = app.persistencia.connectionFactory();
    var QuadroDao = new app.persistencia.QuadroDao(connection);

    QuadroDao.atualiza(quadro, function(erro){
        if (erro){
          res.status(500).send(erro);
          return;
        }

        console.log('Quadro auterado');
     //   res.status(204).send(equipe);
        
    });


  });









}