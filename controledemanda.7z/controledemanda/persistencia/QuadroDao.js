
function QuadroDao(connection) {
    this._connection = connection;
}












QuadroDao.prototype.listaQuadros = function(callback) {
 this._connection.query('SELECT q.CD_EQUIPE,e.NM_EQUIPE,q.CD_QUADRO,q.NM_QUADRO FROM cenopsp1981controledemandas.tb_quadro as q INNER JOIN cenopsp1981controledemandas.tb_equipe as e ON q.CD_EQUIPE=e.CD_EQUIPE',callback);
	this._connection.end(); 
}


QuadroDao.prototype.salvaQuadro = function(quadro,callback) {
	
	//console.log(quadro);
    this._connection.query('INSERT INTO cenopsp1981controledemandas.tb_quadro SET ?', quadro, callback);
    this._connection.end(); 
}

QuadroDao.prototype.buscaquadro = function(quadro,callback) {
	console.log("entrou no daodd");
	//console.log(quadro);
this._connection.query('SELECT * FROM cenopsp1981controledemandas.tb_quadro where CD_QUADRO = ?', [quadro.CD_QUADRO], callback);
this._connection.end(); 
}

QuadroDao.prototype.atualiza = function(quadro,callback) {

	console.log(quadro);
    this._connection.query('UPDATE cenopsp1981controledemandas.tb_quadro SET CD_EQUIPE = ? ,NM_QUADRO=?  where CD_QUADRO= ?', [quadro.CD_EQUIPE,quadro.NM_QUADRO, quadro.CD_QUADRO], callback);
    
    


     this._connection.end(); 
}



module.exports = function(){
    return QuadroDao;   
};