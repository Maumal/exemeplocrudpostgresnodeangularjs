var path = require('path');


module.exports = function(app){

  app.get('/equipe', function(req, res){
    var connection = app.persistencia.connectionFactory();
    var EquipeDao = new app.persistencia.EquipeDao(connection);

    EquipeDao.listaequipe(function(erro, resultado){
      if(erro){
        console.log('Erro ao inserir no banco:' + erro);
        res.status(500).send(erro);
        return;
      } else {
        console.log('yyyy');
    //  console.log('busca equipes');
    res.status(201).json(resultado);
    return;
  }
});
  });

  app.post('/equipe', function(req, res){

   console.log(req.body);
   
   req.assert("NM_EQUIPE",
    "nome da equipe eh obrigatorio").notEmpty();
   req.assert("DS_EQUIPE",
    "Descricao da equipe eh obrigatorio")
   .notEmpty();

   var erros = req.validationErrors();
   if (erros){
    console.log('Erros de validacao encontrados');
    res.status(400).send(erros);
    return;
  }

  var equipe = req.body;

  console.log(equipe);

  console.log('processando uma requisicao de um novo pagamento');
  equipe.DT_EXPIRACAO = "9999-12-31";
  console.log(equipe);

  var connection = app.persistencia.connectionFactory();
  var EquipeDao = new app.persistencia.EquipeDao(connection);

  EquipeDao.salvaequipe(equipe, function(erro, resultado){
    if(erro){
      console.log('Erro ao inserir no banco:' + erro);
      res.status(500).send(erro);
    } else {
      console.log('equipe criada');
      console.log(equipe);
       //    res.location('/equipe/' +resultado);

       res.status(201).json(equipe);
     }
   });

});




  app.delete('/equipe/:CD_EQUIPE', function(req, res){
    var equipe = {};
    var CD_EQUIPE = req.params.CD_EQUIPE;

    equipe.CD_EQUIPE = CD_EQUIPE;
    equipe.DT_EXPIRACAO = new Date;

    console.log(equipe);

    var connection = app.persistencia.connectionFactory();
    var EquipeDao = new app.persistencia.EquipeDao(connection);

    EquipeDao.exclui(equipe, function(erro){
      if (erro){
        res.status(500).send(erro);
        return;
      }

      console.log('pagamento cancelado');
     //   res.status(204).send(equipe);
     
   });
  });

//rota editar
app.get('/equipe/:CD_EQUIPE', function(req, res){

  var equipe = {};
  var CD_EQUIPE = req.params.CD_EQUIPE;
  equipe.CD_EQUIPE = CD_EQUIPE;


  //  equipe.DT_EXPIRACAO = new Date;
  console.log('yyyy');
  console.log(equipe);

  var connection = app.persistencia.connectionFactory();
  var EquipeDao = new app.persistencia.EquipeDao(connection);

  EquipeDao.buscaequipe(equipe, function(erro,resultado){
    if (erro){
      res.status(500).send(erro);
      return;
    }
    
        //console.log('equipe encontrada');
       /// console.log(resultado);
       res.status(201).json(resultado);
       return;
       
     });
});




app.put('/equipe/:CD_EQUIPE', function(req, res){

  var equipe = req.body;
  console.log("entrou no put");
  var CD_EQUIPE = req.params.CD_EQUIPE;
  console.log(CD_EQUIPE);
  console.log(equipe);
  var connection = app.persistencia.connectionFactory();
  var EquipeDao = new app.persistencia.EquipeDao(connection);

  EquipeDao.atualiza(equipe, function(erro){
    if (erro){
      res.status(500).send(erro);
      return;
    }

    console.log('pagamento auterado');
     //   res.status(204).send(equipe);
     
   });
});












}
