
var listaQuadros = angular.module('listaQuadros',[]);

  listaQuadros.controller('quadrosController', function($scope, $http) {



        $scope.buscarEquipes = function() {        
           $scope.equipes = [];
           var request = $http.get('/equipe');    
           request.success(function(data) {
           $scope.equipes = data; 
          // console.log(data);           
        });
           request.error(function(data){
            console.log('Error: ' + data);
        });

 }//Chamando a função buscar
 $scope.buscarEquipes();

$scope.buscarQuadros = function() {        
           $scope.quadros = [];

           var request = $http.get('/quadros');    
           request.success(function(data) {
             $scope.quadros = [];
           $scope.quadros = data; 
           console.log(data);           
        });
           request.error(function(data){
            console.log('Error: ' + data);
        });

 }//Chamando a função buscarFuncionariosEquipes
 $scope.buscarQuadros();

 $scope.criarQuadro = function() {    
        $http.post('/quadro', $scope.formQuadro)
            .success(function(data) {            
           // Limpa o formulário para criação de outras equipes
             $scope.formQuadro = {};            
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });
 $scope.buscarEquipes();  
 $scope.buscarQuadros();
    };



$scope.editarQuadro = function(id) {


        $http.get('/quadros/' + id)

            .success(function(data) {
              console.log(data);
              $scope.quadro=data;
             $scope.formQuadro = $scope.quadro[0];
            

              $scope.formQuadro.NM_QUADRO=$scope.quadro[0].NM_QUADRO;              
                             })
            .error(function(data) {
                console.log('Error: ' + data);
            });
};




$scope.atualizarQuadro = function() {
 

     $http.put('/quadros/' + $scope.formQuadro.CD_QUADRO, $scope.formQuadro)
            .success(function(data) {
            //  $scope.limparQuadro();
               $scope.formQuadro = {};  
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });
$scope.limparQuadro();
$scope.buscarEquipes();  
$scope.buscarQuadros();
 
    };




 $scope.limparQuadro = function() {  

                $scope.formQuadro = {};

    };





  })

