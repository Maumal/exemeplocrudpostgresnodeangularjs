// var path = require('path');
module.exports = function(app){
  app.get('/funcionariosequipes', function(req, res){
    var connection = app.persistencia.connectionFactory();  
    var FuncionarioDao = new app.persistencia.FuncionarioDao(connection);
    FuncionarioDao.listaFuncionarioEquipe(function(erro, resultado){
      if(erro){
        console.log('Erro ao inserir no banco:' + erro);
        res.status(500).send(erro);
        return;
      } else {
      console.log('busca funcionarios');
      res.status(201).json(resultado);
return;
    }
    });
      });


app.post('/funcionario', function(req, res){
console.log("grava funci");
 console.log(req.body);
 
    req.assert("CD_FUNCI",
        "chave eh obrigatorio").notEmpty();
    req.assert("CD_EQUIPE",
      "códido da equipe eh obrigatorio")
    .notEmpty();

    var erros = req.validationErrors();
    if (erros){
      console.log('Erros de validacao encontrados');
      res.status(400).send(erros);
      return;
    }
    var funcionario = req.body;
    funcionario.DT_EXPIRACAO = "9999-12-31";
    console.log(funcionario);
    console.log('processando uma requisicao de um novo pagamento');
    var connection = app.persistencia.connectionFactory();
    var FuncionarioDao = new app.persistencia.FuncionarioDao(connection);

    FuncionarioDao.salvafuncionario(funcionario, function(erro, resultado){
      if(erro){
        console.log('Erro ao inserir no banco:' + erro);
        res.status(500).send(erro);
      } else {
      console.log('funcionário criado');
      console.log(funcionario);
       //    res.location('/equipe/' +resultado);

      res.status(201).json(funcionario);
    }
    });

  });



app.delete('/funcionario/:CD_EQUIPE_FUNCI', function(req, res){
    var funcionario = {};
    var CD_EQUIPE_FUNCI = req.params.CD_EQUIPE_FUNCI;

    funcionario.CD_EQUIPE_FUNCI = CD_EQUIPE_FUNCI;
    funcionario.DT_EXPIRACAO = new Date;

console.log(funcionario);

    var connection = app.persistencia.connectionFactory();
    var FuncionarioDao = new app.persistencia.FuncionarioDao(connection);

    FuncionarioDao.exclui(funcionario, function(erro){
        if (erro){
          res.status(500).send(erro);
          return;
        }

        console.log('FUNCIONARIO cancelado');
     //   res.status(204).send(equipe);
        
    });
  });




//rota editar
app.get('/funcionario/:CD_EQUIPE_FUNCI', function(req, res){
    var funcionario = {};
    var CD_EQUIPE_FUNCI = req.params.CD_EQUIPE_FUNCI;

    funcionario.CD_EQUIPE_FUNCI = CD_EQUIPE_FUNCI;
  //  equipe.DT_EXPIRACAO = new Date;

    var connection = app.persistencia.connectionFactory();
    var FuncionarioDao = new app.persistencia.FuncionarioDao(connection);
    FuncionarioDao.buscafuncionario(funcionario, function(erro,resultado){
        if (erro){
          res.status(500).send(erro);
          return;
        }
        
        //console.log('equipe encontrada');
       /// console.log(resultado);
       res.status(201).json(resultado);
       return;
        
    });


  });

app.put('/funcionario/:CD_EQUIPE_FUNCI', function(req, res){
var funcionario = req.body;
console.log("entrou no put");
var CD_EQUIPE_FUNCI = req.params.CD_EQUIPE_FUNCI;
console.log(funcionario);
var connection = app.persistencia.connectionFactory();
    var FuncionarioDao = new app.persistencia.FuncionarioDao(connection);

    FuncionarioDao.atualiza(funcionario, function(erro){
        if (erro){
          res.status(500).send(erro);
          return;
        }

        console.log('funcionario auterado');
     //   res.status(204).send(equipe);
        
    });
  });




}