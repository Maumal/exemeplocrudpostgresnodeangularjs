var app = angular.module('app',[]);

app.controller('myController', function($scope, $http) {   

// $scope.buscarclientes = function() {   
//   $scope.clientes =null;       
//   var request = $http.get('/clientes');    
//   request.success(function(data) {
//   $scope.clientes =data;             
// });
//   request.error(function(data){
//    console.log('Error: ' + data);
// });
// };

$scope.buscarclientes = function() {   
  $scope.clientes =null;       
  $http({
    method: 'GET',
    url: '/clientes'
  }).then(function successCallback(response) {   
      $scope.clientes =response; 
    }, function errorCallback(response) {
      console.log('Error: ' + response);
    });
};


$scope.buscarclientes();





       
});




