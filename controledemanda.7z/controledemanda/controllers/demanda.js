var path = require('path');


module.exports = function(app){



//rota buscas quadros por equipes
app.get('/quadro/:CD_EQUIPE', function(req, res){

    var equipe = {};
    var CD_EQUIPE = req.params.CD_EQUIPE;

    equipe.CD_EQUIPE = CD_EQUIPE;
 // console.log('busca equipe');
   console.log(equipe);

    var connection = app.persistencia.connectionFactory();
    var DemandasDao = new app.persistencia.DemandasDao(connection);
    DemandasDao.buscaquadrosporequipe(equipe, function(erro,resultado){
        if (erro){
          res.status(500).send(erro);
          return;
        }
        
        //console.log('equipe encontrada');
       /// console.log(resultado);
     

       res.status(201).json(resultado);

       return;
        
    });


  });




var CD_QUADRO;
//rota buscas quadros por equipes
app.get('/cartoes/cartoes/:CD_QUADRO', function(req, res){
  console.log("aaaaaaaaaaaaa");
    var quadro = {};
    CD_QUADRO = req.params.CD_QUADRO;
    quadro.CD_QUADRO = CD_QUADRO;
 //  console.log('busca cartoes');
 console.log(quadro);

    var connection = app.persistencia.connectionFactory();
    var DemandasDao = new app.persistencia.DemandasDao(connection);
    DemandasDao.buscacartoesporquadro(quadro, function(erro,resultado){
        if (erro){
          res.status(500).send(erro);
          return;
        }     




console.log("aaaaaaaaaaaaa");
       console.log(resultado);
       res.status(201).json(resultado);
       return;

        
    });
  });



}