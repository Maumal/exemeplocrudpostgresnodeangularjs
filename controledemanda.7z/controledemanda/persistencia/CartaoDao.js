
function CartaoDao(connection) {
    this._connection = connection;
}


CartaoDao.prototype.listaCartoes = function(callback) {
 this._connection.query('SELECT * FROM cenopsp1981controledemandas.vw_cartao_dados',callback);
	this._connection.end(); 
}

//status do cartão
CartaoDao.prototype.listaCartaoLista = function(callback) {
 this._connection.query('SELECT * FROM cenopsp1981controledemandas.tb_cartao_lista',callback);
 this._connection.end(); 
}

CartaoDao.prototype.listaCartaoListaPriorizacao = function(callback) {
 this._connection.query('SELECT * FROM cenopsp1981controledemandas.tb_cartao_nivel_priorizacao',callback);
	this._connection.end(); 
}


CartaoDao.prototype.salvaCartao = function(cartao,callback) {
//	console.log("entrou no dao");
//	console.log(cartao);
    this._connection.query('INSERT INTO cenopsp1981controledemandas.tb_cartao SET ?', cartao, callback);
    this._connection.end(); 
}

//////aqui


CartaoDao.prototype.buscacartao = function(cartao,callback) {
//	console.log("entrou no dao");
	//console.log(quadro);
this._connection.query('SELECT * FROM cenopsp1981controledemandas.tb_cartao where CD_CARTAO = ?', [cartao.CD_CARTAO], callback);
this._connection.end(); 
}


CartaoDao.prototype.atualiza = function(cartao,callback) {
//	console.log("entrou no dao");
//	console.log(cartao);
var dataFim=cartao.DT_FIM;
dataFim=dataFim.substring(0, 10); 
//console.log(dataFim);


    this._connection.query('UPDATE cenopsp1981controledemandas.tb_cartao SET NM_CARTAO = ? ,DS_CARTAO=?,CD_QUADRO=?,CD_CARTAO_LISTA=?,CD_CARTAO_NIVEL_PRIORIZACAO=?,DT_FIM=?  where CD_CARTAO= ?', [cartao.NM_CARTAO,cartao.DS_CARTAO,cartao.CD_QUADRO,cartao.CD_CARTAO_LISTA,cartao.CD_CARTAO_NIVEL_PRIORIZACAO,dataFim,cartao.CD_CARTAO], callback);
    
    


     this._connection.end(); 
}



module.exports = function(){
    return CartaoDao;   
};