var path = require('path');
module.exports = function(app){
const conexaoDao = require('../persistencia/exemploDao')
    app.get('/clientes', conexaoDao.getClientes)
    app.get('/clientes/:id', conexaoDao.getClientesById)
    app.post('/clientes', conexaoDao.createCliente)
    app.put('/clientes/:id', conexaoDao.updateCliente)
    app.delete('/clientes/:id', conexaoDao.deleteCliente) 
}