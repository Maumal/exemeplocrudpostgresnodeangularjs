var path = require('path');
module.exports = function(app){
const conexaoDao = require('../persistencia/exemploDao')
    app.get('/clientes', conexaoDao.getClientes)
    app.get('/Clientes/:id', conexaoDao.getClientesById)
    app.post('/Clientes', conexaoDao.createCliente)
    app.put('/Clientes/:id', conexaoDao.updateCliente)
    app.delete('/Clientes/:id', conexaoDao.deleteCliente)
  
}